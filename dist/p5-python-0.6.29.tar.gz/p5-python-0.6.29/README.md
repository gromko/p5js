# p5 is a friendly tool for learning to code and make art.

It is a free and open-source Python library built by an inclusive, nurturing community. p5 welcomes artists, designers, beginners, educators, and anyone else!
p5 is a Python library that provides high level drawing functionality to help you quickly create simulations and interactive art using Python.
